export * from './@material-extend';
export { default as ThemeConfig } from './core';
