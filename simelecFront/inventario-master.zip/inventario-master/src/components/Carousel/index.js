export { default as CarouselCustomPaging1 } from './CarouselCustomPaging1';
export { default as CarouselCustomPaging2 } from './CarouselCustomPaging2';

export { default as CarouselArrowsBasic1 } from './CarouselArrowsBasic1';
export { default as CarouselArrowsBasic2 } from './CarouselArrowsBasic2';
export { default as CarouselArrowsIndex } from './CarouselArrowsIndex';
