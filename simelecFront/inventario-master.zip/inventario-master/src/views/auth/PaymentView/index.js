import React from 'react'
import { Typography } from '@material-ui/core'

const index = () => {
  return (
    <div>
      <Typography>Aquí podré pagar</Typography>
    </div>
  )
}

export default index;
